$(document).ready(function() { 
    $('.carousel-home').flickity({
    groupCells:true,
    autoPlay:true,
    wrapAround:true,
    pauseAutoPlayOnHover:true,
    imagesLoaded: true,
    pageDots: false,
    }); 
  });